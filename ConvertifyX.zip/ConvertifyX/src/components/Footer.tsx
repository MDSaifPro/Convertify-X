import Link from "next/link";
import { FiGithub } from "react-icons/fi";
import { FaDev } from "react-icons/fa";


export function SiteFooter() {
  return (
    <footer className="py-6 px-16 md:py-0">
      <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
        <p className="text-center text-md leading-loose text-muted-foreground md:text-left">
          {/* the md:text-center is for testing, it might chafe to Left if encountered any issues */}
          Built with <span className="text-red-600">❤️</span> by <Link
          href={"https://mdsaifprog2.netlify.app"}
          target="_blank "
        >MD Saif Prog Dev.</Link>
        </p>
        <div className="space-x-6 flex items-center">
        <Link
          href={"https://dev.to/mdsaifprogdev"}
          target="_blank"
        >
          <FaDev  className="w-5 h-5 text-muted-foreground" />
        </Link>

        <Link
          href={"https://github.com/MDSaifPro"}
          target="_blank "
        >
          <FiGithub className="w-5 h-5 text-muted-foreground" />
        </Link>
        </div>
      </div>
    </footer>
  );
}
